"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Code, Zap, Globe, Sparkles, Rocket } from "lucide-react"

export function Hero() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  const scrollToContact = () => {
    const element = document.getElementById("contact")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20"
      style={{
        background: `
          radial-gradient(circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(251, 146, 60, 0.1) 0%, transparent 50%),
          linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%)
        `,
      }}
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 gradient-orange rounded-full opacity-20 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-20 right-10 w-96 h-96 gradient-purple rounded-full opacity-20 animate-float blur-3xl"
          style={{ animationDelay: "2s" }}
        ></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 gradient-blue rounded-full opacity-20 animate-morphing blur-2xl"></div>

        {/* Floating geometric shapes */}
        <div
          className="absolute top-1/4 right-1/4 w-4 h-4 bg-orange-400 rotate-45 animate-float opacity-60"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute bottom-1/3 left-1/4 w-6 h-6 bg-purple-400 rounded-full animate-float opacity-60"
          style={{ animationDelay: "3s" }}
        ></div>
        <div
          className="absolute top-1/3 left-1/6 w-3 h-3 bg-blue-400 animate-float opacity-60"
          style={{ animationDelay: "4s" }}
        ></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        <div className="text-center">
          {/* Animated icon cluster */}
          <div className={`flex justify-center space-x-6 mb-12 ${isVisible ? "animate-scale-in" : "opacity-0"}`}>
            <div className="relative">
              <div className="p-4 glass rounded-2xl hover-lift hover-glow group cursor-pointer">
                <Code className="h-10 w-10 text-orange-400 group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center animate-pulse-glow">
                  <Sparkles className="h-3 w-3 text-white" />
                </div>
              </div>
            </div>

            <div className="relative" style={{ animationDelay: "0.2s" }}>
              <div className="p-4 glass rounded-2xl hover-lift hover-glow group cursor-pointer">
                <Zap className="h-10 w-10 text-yellow-400 group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center animate-pulse-glow">
                  <Rocket className="h-3 w-3 text-white" />
                </div>
              </div>
            </div>

            <div className="relative" style={{ animationDelay: "0.4s" }}>
              <div className="p-4 glass rounded-2xl hover-lift hover-glow group cursor-pointer">
                <Globe className="h-10 w-10 text-blue-400 group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center animate-pulse-glow">
                  <Sparkles className="h-3 w-3 text-white" />
                </div>
              </div>
            </div>
          </div>

          {/* Main heading with gradient text */}
          <h1 className={`text-5xl md:text-7xl font-bold mb-8 ${isVisible ? "animate-slide-left" : "opacity-0"}`}>
            <span className="bg-gradient-to-r from-white via-orange-200 to-orange-400 bg-clip-text text-transparent animate-text-glow">
              Crafting Fast,
            </span>
            <br />
            <span className="bg-gradient-to-r from-orange-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">
              Functional, and
            </span>
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-orange-400 bg-clip-text text-transparent">
              Future-Ready
            </span>
            <br />
            <span className="text-white">Web Solutions</span>
          </h1>

          {/* Subtitle with typewriter effect */}
          <p
            className={`text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed ${isVisible ? "animate-slide-right" : "opacity-0"}`}
            style={{ animationDelay: "0.3s" }}
          >
            At <span className="text-orange-400 font-semibold">Wixxle Forge</span>, we transform your digital vision
            into reality. Specializing in custom web development solutions for
            <span className="text-purple-400 font-semibold"> startups</span>,
            <span className="text-blue-400 font-semibold"> entrepreneurs</span>, and
            <span className="text-green-400 font-semibold"> local businesses</span>.
          </p>

          {/* CTA buttons with advanced styling */}
          <div
            className={`flex flex-col sm:flex-row gap-6 justify-center ${isVisible ? "animate-scale-in" : "opacity-0"}`}
            style={{ animationDelay: "0.6s" }}
          >
            <Button
              size="lg"
              className="group relative overflow-hidden bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 py-4 rounded-2xl text-lg font-semibold hover-lift"
              onClick={scrollToContact}
            >
              <span className="relative z-10 flex items-center">
                Start Your Project
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="group glass text-white border-white/30 hover:border-orange-400 px-8 py-4 rounded-2xl text-lg font-semibold hover-lift backdrop-blur-sm bg-transparent"
              onClick={() => {
                const element = document.getElementById("portfolio")
                if (element) {
                  element.scrollIntoView({ behavior: "smooth" })
                }
              }}
            >
              <span className="group-hover:text-orange-400 transition-colors duration-300">View Our Work</span>
            </Button>
          </div>

          {/* Stats section */}
          <div
            className={`mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}
            style={{ animationDelay: "0.9s" }}
          >
            {[
              { number: "50+", label: "Projects Completed" },
              { number: "25+", label: "Happy Clients" },
              { number: "3+", label: "Years Experience" },
              { number: "24/7", label: "Support Available" },
            ].map((stat, index) => (
              <div key={index} className="glass rounded-xl p-6 hover-lift group">
                <div className="text-3xl font-bold text-orange-400 mb-2 group-hover:scale-110 transition-transform duration-300">
                  {stat.number}
                </div>
                <div className="text-gray-300 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-orange-400 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  )
}
