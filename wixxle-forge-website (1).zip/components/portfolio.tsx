"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github, Eye, Heart, TrendingUp } from "lucide-react"

export function Portfolio() {
  const [hoveredProject, setHoveredProject] = useState<number | null>(null)
  const [visibleProjects, setVisibleProjects] = useState<number[]>([])
  const sectionRef = useRef<HTMLElement>(null)

  const projects = [
    {
      name: "TechStart Dashboard",
      image: "/placeholder.svg?height=400&width=600",
      description:
        "A comprehensive analytics dashboard for a tech startup, featuring real-time data visualization and user management.",
      techStack: ["React", "Next.js", "TypeScript", "Tailwind CSS", "Chart.js"],
      liveUrl: "#",
      githubUrl: "#",
      category: "Dashboard",
      gradient: "from-blue-500 to-purple-600",
      stats: { views: "2.5K", likes: "89", growth: "+23%" },
    },
    {
      name: "LocalBiz E-commerce",
      image: "/placeholder.svg?height=400&width=600",
      description:
        "Full-featured e-commerce platform for local businesses with inventory management and payment processing.",
      techStack: ["Next.js", "Stripe", "PostgreSQL", "Prisma", "Tailwind CSS"],
      liveUrl: "#",
      githubUrl: "#",
      category: "E-commerce",
      gradient: "from-green-500 to-teal-600",
      stats: { views: "3.2K", likes: "124", growth: "+45%" },
    },
    {
      name: "RestaurantPro Website",
      image: "/placeholder.svg?height=400&width=600",
      description: "Modern restaurant website with online ordering system, reservation booking, and menu management.",
      techStack: ["React", "Node.js", "MongoDB", "Express", "Socket.io"],
      liveUrl: "#",
      githubUrl: "#",
      category: "Restaurant",
      gradient: "from-orange-500 to-red-600",
      stats: { views: "1.8K", likes: "67", growth: "+18%" },
    },
    {
      name: "HealthCare Portal",
      image: "/placeholder.svg?height=400&width=600",
      description:
        "Patient management system for healthcare providers with appointment scheduling and medical records.",
      techStack: ["Next.js", "TypeScript", "Supabase", "Tailwind CSS"],
      liveUrl: "#",
      githubUrl: "#",
      category: "Healthcare",
      gradient: "from-purple-500 to-pink-600",
      stats: { views: "2.1K", likes: "95", growth: "+32%" },
    },
    {
      name: "EduLearn Platform",
      image: "/placeholder.svg?height=400&width=600",
      description: "Online learning platform with course management, video streaming, and progress tracking.",
      techStack: ["React", "Firebase", "Material-UI", "Video.js"],
      liveUrl: "#",
      githubUrl: "#",
      category: "Education",
      gradient: "from-indigo-500 to-blue-600",
      stats: { views: "4.1K", likes: "156", growth: "+67%" },
    },
    {
      name: "FinanceTracker App",
      image: "/placeholder.svg?height=400&width=600",
      description: "Personal finance management application with expense tracking, budgeting, and financial insights.",
      techStack: ["Next.js", "Chart.js", "PostgreSQL", "Tailwind CSS"],
      liveUrl: "#",
      githubUrl: "#",
      category: "Finance",
      gradient: "from-yellow-500 to-orange-600",
      stats: { views: "2.9K", likes: "112", growth: "+41%" },
    },
  ]

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number.parseInt(entry.target.getAttribute("data-index") || "0")
            setVisibleProjects((prev) => [...prev, index])
          }
        })
      },
      { threshold: 0.1 },
    )

    const projects = sectionRef.current?.querySelectorAll(".project-card")
    projects?.forEach((project) => observer.observe(project))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="portfolio" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 gradient-purple rounded-full opacity-10 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 gradient-orange rounded-full opacity-10 animate-float blur-3xl"
          style={{ animationDelay: "2s" }}
        ></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 gradient-blue rounded-full opacity-10 animate-morphing blur-2xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 glass text-orange-400 rounded-full text-sm font-medium mb-4">
            <Eye className="h-4 w-4 mr-2" />
            Featured Work
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Our{" "}
            <span className="bg-gradient-to-r from-orange-400 to-purple-400 bg-clip-text text-transparent">
              Portfolio
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Explore some of our recent projects that showcase our expertise in web development and design.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card
              key={index}
              data-index={index}
              className={`project-card group relative overflow-hidden border-0 bg-gray-800/50 backdrop-blur-sm hover:bg-gray-800/70 transition-all duration-500 hover-lift ${
                visibleProjects.includes(index) ? "animate-scale-in" : "opacity-0"
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
              onMouseEnter={() => setHoveredProject(index)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* Project image with overlay */}
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />

                {/* Gradient overlay */}
                <div
                  className={`absolute inset-0 bg-gradient-to-t ${project.gradient} opacity-0 group-hover:opacity-80 transition-opacity duration-500`}
                ></div>

                {/* Category badge */}
                <div className="absolute top-4 left-4 px-3 py-1 glass text-white text-xs font-medium rounded-full">
                  {project.category}
                </div>

                {/* Stats overlay */}
                <div
                  className={`absolute top-4 right-4 flex space-x-2 transition-all duration-500 ${
                    hoveredProject === index ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
                  }`}
                >
                  <div className="glass px-2 py-1 rounded-lg text-white text-xs flex items-center">
                    <Eye className="h-3 w-3 mr-1" />
                    {project.stats.views}
                  </div>
                  <div className="glass px-2 py-1 rounded-lg text-white text-xs flex items-center">
                    <Heart className="h-3 w-3 mr-1" />
                    {project.stats.likes}
                  </div>
                </div>

                {/* Action buttons overlay */}
                <div
                  className={`absolute inset-0 flex items-center justify-center space-x-4 transition-all duration-500 ${
                    hoveredProject === index ? "opacity-100" : "opacity-0"
                  }`}
                >
                  <Button
                    size="sm"
                    className="glass text-white border-white/30 hover:border-orange-400 hover:text-orange-400"
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Live Demo
                  </Button>
                  <Button
                    size="sm"
                    className="glass text-white border-white/30 hover:border-purple-400 hover:text-purple-400"
                  >
                    <Github className="h-4 w-4 mr-1" />
                    Code
                  </Button>
                </div>
              </div>

              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-white group-hover:text-orange-400 transition-colors duration-300">
                    {project.name}
                  </h3>
                  <div className="flex items-center text-green-400 text-sm">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    {project.stats.growth}
                  </div>
                </div>

                <p className="text-gray-300 mb-4 text-sm leading-relaxed">{project.description}</p>

                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-2">Tech Stack:</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.techStack.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-2 py-1 bg-gray-700/50 text-gray-300 text-xs rounded-md hover:bg-orange-500/20 hover:text-orange-400 transition-colors duration-300 cursor-default"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Progress bar animation */}
                <div className="w-full bg-gray-700 rounded-full h-1 mb-4">
                  <div
                    className={`h-1 bg-gradient-to-r ${project.gradient} rounded-full transition-all duration-1000 ${
                      visibleProjects.includes(index) ? "w-full" : "w-0"
                    }`}
                    style={{ transitionDelay: `${index * 0.2}s` }}
                  ></div>
                </div>
              </CardContent>

              {/* Decorative corner */}
              <div className="absolute -bottom-2 -right-2 w-20 h-20 bg-gradient-to-br from-white/5 to-transparent rounded-full group-hover:scale-150 transition-transform duration-500"></div>
            </Card>
          ))}
        </div>

        {/* Call to action */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center px-8 py-4 glass text-white rounded-2xl font-semibold text-lg hover:scale-105 transition-transform duration-300 cursor-pointer hover-glow">
            View All Projects
            <ExternalLink className="ml-2 h-5 w-5" />
          </div>
        </div>
      </div>
    </section>
  )
}
