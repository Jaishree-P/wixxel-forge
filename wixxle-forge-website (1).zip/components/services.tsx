"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Code, Palette, ShoppingCart, Smartphone, Wrench, ArrowRight, Star } from "lucide-react"

export function Services() {
  const [visibleCards, setVisibleCards] = useState<number[]>([])
  const sectionRef = useRef<HTMLElement>(null)

  const services = [
    {
      icon: Code,
      title: "Web Development",
      description:
        "Custom websites and web applications built with modern technologies like React, Next.js, and Node.js.",
      features: ["Responsive Design", "SEO Optimization", "Performance Focused", "Scalable Architecture"],
      gradient: "from-orange-400 to-red-500",
      bgGradient: "from-orange-50 to-red-50",
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      price: "Starting at $2,999",
    },
    {
      icon: Palette,
      title: "UI/UX Design",
      description: "Beautiful, intuitive designs that provide exceptional user experiences and drive conversions.",
      features: ["User Research", "Wireframing", "Prototyping", "Visual Design"],
      gradient: "from-purple-400 to-pink-500",
      bgGradient: "from-purple-50 to-pink-50",
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      price: "Starting at $1,999",
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Solutions",
      description: "Complete online stores with payment integration, inventory management, and admin dashboards.",
      features: ["Payment Gateway", "Inventory System", "Order Management", "Analytics Dashboard"],
      gradient: "from-green-400 to-blue-500",
      bgGradient: "from-green-50 to-blue-50",
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      price: "Starting at $4,999",
    },
    {
      icon: Smartphone,
      title: "Mobile App Integration",
      description: "Seamless integration between web and mobile platforms for a unified user experience.",
      features: ["API Development", "Cross-Platform", "Real-time Sync", "Push Notifications"],
      gradient: "from-blue-400 to-indigo-500",
      bgGradient: "from-blue-50 to-indigo-50",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      price: "Starting at $3,999",
    },
    {
      icon: Wrench,
      title: "Maintenance & Support",
      description: "Ongoing maintenance, updates, and technical support to keep your website running smoothly.",
      features: ["24/7 Monitoring", "Security Updates", "Performance Optimization", "Bug Fixes"],
      gradient: "from-yellow-400 to-orange-500",
      bgGradient: "from-yellow-50 to-orange-50",
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      price: "Starting at $299/month",
    },
  ]

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number.parseInt(entry.target.getAttribute("data-index") || "0")
            setVisibleCards((prev) => [...prev, index])
          }
        })
      },
      { threshold: 0.1 },
    )

    const cards = sectionRef.current?.querySelectorAll(".service-card")
    cards?.forEach((card) => observer.observe(card))

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="services"
      className="py-20 bg-gradient-to-br from-gray-50 via-white to-gray-100 relative overflow-hidden"
    >
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 gradient-purple rounded-full opacity-5 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-0 right-1/4 w-80 h-80 gradient-orange rounded-full opacity-5 animate-float blur-3xl"
          style={{ animationDelay: "3s" }}
        ></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-medium mb-4">
            <Star className="h-4 w-4 mr-2" />
            Premium Services
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Our{" "}
            <span className="bg-gradient-to-r from-orange-600 to-purple-600 bg-clip-text text-transparent">
              Services
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We offer comprehensive web development services to help your business thrive in the digital world with
            cutting-edge solutions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              data-index={index}
              className={`service-card group relative overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover-lift ${
                visibleCards.includes(index) ? "animate-scale-in" : "opacity-0"
              }`}
              style={{
                animationDelay: `${index * 0.1}s`,
                background: `linear-gradient(135deg, ${service.bgGradient.replace("from-", "").replace(" to-", ", ")})`,
              }}
            >
              {/* Gradient overlay */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
              ></div>

              {/* Floating icon background */}
              <div className="absolute top-4 right-4 w-20 h-20 bg-white/20 rounded-full blur-xl group-hover:scale-150 transition-transform duration-500"></div>

              <CardHeader className="relative z-10">
                <div
                  className={`w-16 h-16 ${service.iconBg} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}
                >
                  <service.icon className={`h-8 w-8 ${service.iconColor}`} />
                </div>
                <CardTitle className="text-2xl font-bold text-gray-900 group-hover:text-gray-800 transition-colors">
                  {service.title}
                </CardTitle>
                <div
                  className={`text-lg font-semibold bg-gradient-to-r ${service.gradient} bg-clip-text text-transparent`}
                >
                  {service.price}
                </div>
              </CardHeader>

              <CardContent className="relative z-10">
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>

                <div className="space-y-3 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center group/feature">
                      <div
                        className={`w-2 h-2 bg-gradient-to-r ${service.gradient} rounded-full mr-3 group-hover/feature:scale-150 transition-transform duration-300`}
                      ></div>
                      <span className="text-gray-700 group-hover/feature:text-gray-900 transition-colors duration-300">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>

                <button
                  className={`w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r ${service.gradient} text-white rounded-xl font-semibold group-hover:shadow-lg transition-all duration-300 hover:scale-105`}
                >
                  Get Started
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                </button>
              </CardContent>

              {/* Decorative elements */}
              <div className="absolute -bottom-2 -right-2 w-24 h-24 bg-gradient-to-br from-white/20 to-transparent rounded-full group-hover:scale-150 transition-transform duration-500"></div>
            </Card>
          ))}
        </div>

        {/* Call to action */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-orange-500 to-purple-600 text-white rounded-2xl font-semibold text-lg hover:scale-105 transition-transform duration-300 cursor-pointer shadow-lg hover:shadow-xl">
            Need a Custom Solution?
            <ArrowRight className="ml-2 h-5 w-5" />
          </div>
        </div>
      </div>
    </section>
  )
}
