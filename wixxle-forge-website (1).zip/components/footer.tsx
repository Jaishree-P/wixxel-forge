"use client"

import { useState, useEffect, useRef } from "react"
import { Github, Linkedin, Twitter, Mail, Phone, MapPin, ArrowUp, Heart, Zap } from "lucide-react"

export function Footer() {
  const [visibleElements, setVisibleElements] = useState<number[]>([])
  const [showScrollTop, setShowScrollTop] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number.parseInt(entry.target.getAttribute("data-index") || "0")
            setVisibleElements((prev) => [...prev, index])
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = sectionRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((element) => observer.observe(element))

    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500)
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      observer.disconnect()
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <footer
      ref={sectionRef}
      className="bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white relative overflow-hidden"
    >
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 gradient-purple rounded-full opacity-5 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 gradient-orange rounded-full opacity-5 animate-float blur-3xl"
          style={{ animationDelay: "2s" }}
        ></div>

        {/* Floating elements */}
        <div
          className="absolute top-20 right-20 w-4 h-4 bg-orange-400/20 rotate-45 animate-float"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute bottom-32 left-32 w-6 h-6 bg-purple-400/20 rounded-full animate-float"
          style={{ animationDelay: "3s" }}
        ></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        {/* Main footer content */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company info */}
          <div
            className={`lg:col-span-2 animate-on-scroll ${visibleElements.includes(0) ? "animate-slide-left" : "opacity-0"}`}
            data-index="0"
          >
            <div className="flex items-center mb-6 group">
              <span className="text-3xl font-bold group-hover:text-orange-400 transition-colors duration-300">
                Wixxle{" "}
                <span className="text-orange-500 group-hover:text-purple-400 transition-colors duration-300">
                  Forge
                </span>
              </span>
              <div className="ml-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Zap className="h-6 w-6 text-orange-400 animate-pulse" />
              </div>
            </div>
            <p className="text-gray-300 mb-8 max-w-md leading-relaxed">
              Crafting fast, functional, and future-ready web solutions for businesses that want to make their mark in
              the digital world. Let's build something amazing together.
            </p>

            {/* Contact info */}
            <div className="space-y-4 mb-8">
              {[
                { icon: Mail, text: "hello@wixxleforge.com", gradient: "from-blue-500 to-purple-600" },
                { icon: Phone, text: "+1 (555) 123-4567", gradient: "from-green-500 to-blue-600" },
                { icon: MapPin, text: "123 Tech Street, Digital City", gradient: "from-orange-500 to-red-600" },
              ].map((contact, index) => (
                <div key={index} className="flex items-center group hover-lift">
                  <div
                    className={`w-10 h-10 bg-gradient-to-r ${contact.gradient} rounded-lg flex items-center justify-center mr-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}
                  >
                    <contact.icon className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-gray-300 group-hover:text-white transition-colors duration-300">
                    {contact.text}
                  </span>
                </div>
              ))}
            </div>

            {/* Social media */}
            <div className="flex space-x-4">
              {[
                { icon: Github, href: "#", gradient: "from-gray-600 to-gray-800" },
                { icon: Linkedin, href: "#", gradient: "from-blue-600 to-blue-800" },
                { icon: Twitter, href: "#", gradient: "from-blue-400 to-blue-600" },
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 bg-gradient-to-r ${social.gradient} rounded-xl flex items-center justify-center hover:scale-110 hover:rotate-6 transition-all duration-300 hover-glow`}
                >
                  <social.icon className="h-6 w-6 text-white" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div
            className={`animate-on-scroll ${visibleElements.includes(1) ? "animate-slide-right" : "opacity-0"}`}
            data-index="1"
            style={{ animationDelay: "0.2s" }}
          >
            <h3 className="text-xl font-bold mb-6 flex items-center">
              <div className="w-2 h-2 bg-orange-400 rounded-full mr-3 animate-pulse"></div>
              Quick Links
            </h3>
            <ul className="space-y-3">
              {[
                { id: "home", label: "Home" },
                { id: "about", label: "About" },
                { id: "services", label: "Services" },
                { id: "portfolio", label: "Portfolio" },
                { id: "contact", label: "Contact" },
              ].map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-gray-400 hover:text-orange-400 transition-all duration-300 hover:translate-x-2 flex items-center group"
                  >
                    <div className="w-0 h-0.5 bg-orange-400 group-hover:w-4 transition-all duration-300 mr-0 group-hover:mr-2"></div>
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div
            className={`animate-on-scroll ${visibleElements.includes(2) ? "animate-slide-right" : "opacity-0"}`}
            data-index="2"
            style={{ animationDelay: "0.4s" }}
          >
            <h3 className="text-xl font-bold mb-6 flex items-center">
              <div className="w-2 h-2 bg-purple-400 rounded-full mr-3 animate-pulse"></div>
              Services
            </h3>
            <ul className="space-y-3 text-gray-400">
              {[
                "Web Development",
                "UI/UX Design",
                "E-commerce Solutions",
                "Mobile App Integration",
                "Maintenance & Support",
              ].map((service, index) => (
                <li
                  key={index}
                  className="hover:text-purple-400 transition-colors duration-300 cursor-pointer hover:translate-x-2 flex items-center group"
                >
                  <div className="w-0 h-0.5 bg-purple-400 group-hover:w-4 transition-all duration-300 mr-0 group-hover:mr-2"></div>
                  {service}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter signup */}
        <div
          className={`bg-gradient-to-r from-orange-500/10 to-purple-500/10 rounded-2xl p-8 mb-12 border border-white/10 animate-on-scroll ${visibleElements.includes(3) ? "animate-scale-in" : "opacity-0"}`}
          data-index="3"
          style={{ animationDelay: "0.6s" }}
        >
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Stay Updated</h3>
            <p className="text-gray-300 mb-6">Get the latest updates on web development trends and our new projects.</p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-400 transition-all duration-300"
              />
              <button className="px-6 py-3 bg-gradient-to-r from-orange-500 to-purple-600 rounded-xl font-semibold hover:scale-105 transition-all duration-300 hover-glow">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className={`border-t border-white/10 pt-8 animate-on-scroll ${visibleElements.includes(4) ? "animate-fade-in-up" : "opacity-0"}`}
          data-index="4"
          style={{ animationDelay: "0.8s" }}
        >
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0 flex items-center">
              © 2025 Wixxle Forge. All rights reserved. Built with{" "}
              <Heart className="h-4 w-4 text-red-500 mx-2 animate-pulse" />
              and cutting-edge technology.
            </p>
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <a href="#" className="hover:text-orange-400 transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-orange-400 transition-colors duration-300">
                Terms of Service
              </a>
              <a href="#" className="hover:text-orange-400 transition-colors duration-300">
                Cookies
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col space-y-3">
        {/* Scroll to top button */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="w-12 h-12 glass rounded-full flex items-center justify-center text-white hover:text-orange-400 hover:scale-110 transition-all duration-300 animate-bounce"
          >
            <ArrowUp className="h-6 w-6" />
          </button>
        )}

        {/* Main CTA */}
        <button
          onClick={() => scrollToSection("contact")}
          className="bg-gradient-to-r from-orange-500 to-purple-600 hover:from-orange-600 hover:to-purple-700 text-white px-6 py-3 rounded-full shadow-lg transition-all duration-300 hover:scale-105 animate-pulse-glow font-semibold"
        >
          Let's Build Together! 🚀
        </button>
      </div>
    </footer>
  )
}
