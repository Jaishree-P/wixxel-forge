"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Send, MessageCircle, Clock, CheckCircle } from "lucide-react"

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [focusedField, setFocusedField] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsSubmitting(false)
    setIsSubmitted(true)
    setFormData({ name: "", email: "", message: "" })

    setTimeout(() => setIsSubmitted(false), 5000)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-br from-gray-50 via-white to-orange-50 relative overflow-hidden"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 gradient-orange rounded-full opacity-5 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-1/4 left-1/4 w-80 h-80 gradient-purple rounded-full opacity-5 animate-float blur-3xl"
          style={{ animationDelay: "2s" }}
        ></div>

        {/* Floating geometric shapes */}
        <div className="absolute top-20 left-20 w-4 h-4 bg-orange-300 rotate-45 animate-float opacity-30"></div>
        <div
          className="absolute bottom-40 right-32 w-6 h-6 bg-purple-300 rounded-full animate-float opacity-30"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 right-20 w-3 h-3 bg-blue-300 animate-float opacity-30"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-medium mb-4 animate-pulse-glow">
            <MessageCircle className="h-4 w-4 mr-2" />
            Let's Connect
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Let's Build Your{" "}
            <span className="bg-gradient-to-r from-orange-600 to-purple-600 bg-clip-text text-transparent">
              Digital Future
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ready to start your project? Get in touch with us today and let's discuss how we can help bring your vision
            to life.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="relative">
            <Card className="overflow-hidden border-0 shadow-2xl hover:shadow-3xl transition-shadow duration-500 bg-white/80 backdrop-blur-sm">
              <CardHeader className="bg-gradient-to-r from-orange-500 to-purple-600 text-white relative overflow-hidden">
                <div className="absolute inset-0 bg-black/10"></div>
                <CardTitle className="relative z-10 text-2xl flex items-center">
                  <Send className="h-6 w-6 mr-3" />
                  Send us a message
                </CardTitle>
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/10 rounded-full animate-pulse"></div>
              </CardHeader>

              <CardContent className="p-8">
                {isSubmitted ? (
                  <div className="text-center py-12 animate-scale-in">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
                      <CheckCircle className="h-10 w-10 text-green-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Message Sent!</h3>
                    <p className="text-gray-600">Thank you for reaching out. We'll get back to you within 24 hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="relative">
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                        Name
                      </label>
                      <div className="relative">
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={handleChange}
                          onFocus={() => setFocusedField("name")}
                          onBlur={() => setFocusedField(null)}
                          placeholder="Your full name"
                          className={`transition-all duration-300 ${
                            focusedField === "name" ? "ring-2 ring-orange-500 border-orange-500 scale-105" : ""
                          }`}
                        />
                        <div
                          className={`absolute inset-0 bg-gradient-to-r from-orange-500/20 to-purple-500/20 rounded-md opacity-0 transition-opacity duration-300 pointer-events-none ${
                            focusedField === "name" ? "opacity-100" : ""
                          }`}
                        ></div>
                      </div>
                    </div>

                    <div className="relative">
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <div className="relative">
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={handleChange}
                          onFocus={() => setFocusedField("email")}
                          onBlur={() => setFocusedField(null)}
                          placeholder="your.email@example.com"
                          className={`transition-all duration-300 ${
                            focusedField === "email" ? "ring-2 ring-orange-500 border-orange-500 scale-105" : ""
                          }`}
                        />
                        <div
                          className={`absolute inset-0 bg-gradient-to-r from-orange-500/20 to-purple-500/20 rounded-md opacity-0 transition-opacity duration-300 pointer-events-none ${
                            focusedField === "email" ? "opacity-100" : ""
                          }`}
                        ></div>
                      </div>
                    </div>

                    <div className="relative">
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                        Message
                      </label>
                      <div className="relative">
                        <Textarea
                          id="message"
                          name="message"
                          required
                          value={formData.message}
                          onChange={handleChange}
                          onFocus={() => setFocusedField("message")}
                          onBlur={() => setFocusedField(null)}
                          placeholder="Tell us about your project..."
                          rows={5}
                          className={`transition-all duration-300 ${
                            focusedField === "message" ? "ring-2 ring-orange-500 border-orange-500 scale-105" : ""
                          }`}
                        />
                        <div
                          className={`absolute inset-0 bg-gradient-to-r from-orange-500/20 to-purple-500/20 rounded-md opacity-0 transition-opacity duration-300 pointer-events-none ${
                            focusedField === "message" ? "opacity-100" : ""
                          }`}
                        ></div>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-orange-500 to-purple-600 hover:from-orange-600 hover:to-purple-700 text-white py-4 text-lg font-semibold rounded-xl hover:scale-105 transition-all duration-300 relative overflow-hidden group"
                    >
                      <span className="relative z-10 flex items-center justify-center">
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send className="h-5 w-5 mr-2 group-hover:translate-x-1 transition-transform duration-300" />
                            Send Message
                          </>
                        )}
                      </span>
                      <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-8">Get in Touch</h3>
              <div className="space-y-6">
                {[
                  {
                    icon: Mail,
                    title: "Email",
                    info: "hello@wixxleforge.com",
                    gradient: "from-blue-500 to-purple-600",
                  },
                  { icon: Phone, title: "Phone", info: "+1 (555) 123-4567", gradient: "from-green-500 to-blue-600" },
                  {
                    icon: MapPin,
                    title: "Office",
                    info: "123 Tech Street, Digital City, DC 12345",
                    gradient: "from-orange-500 to-red-600",
                  },
                ].map((contact, index) => (
                  <div
                    key={index}
                    className="flex items-center group hover-lift p-4 rounded-xl hover:bg-white/50 transition-all duration-300"
                  >
                    <div
                      className={`w-14 h-14 bg-gradient-to-r ${contact.gradient} rounded-2xl flex items-center justify-center mr-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}
                    >
                      <contact.icon className="h-7 w-7 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 text-lg">{contact.title}</p>
                      <p className="text-gray-600 group-hover:text-gray-800 transition-colors duration-300">
                        {contact.info}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Why Work With Us Card */}
            <Card className="bg-gradient-to-br from-orange-50 to-purple-50 border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden">
              <CardContent className="p-8 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-orange-200/30 to-purple-200/30 rounded-full -translate-y-16 translate-x-16"></div>
                <h4 className="text-2xl font-bold mb-6 text-gray-900">Why Work With Us?</h4>
                <ul className="space-y-4">
                  {[
                    "Free initial consultation",
                    "Transparent pricing",
                    "Agile development process",
                    "Ongoing support included",
                  ].map((item, index) => (
                    <li key={index} className="flex items-center group">
                      <div className="w-3 h-3 bg-gradient-to-r from-orange-500 to-purple-600 rounded-full mr-4 group-hover:scale-150 transition-transform duration-300"></div>
                      <span className="text-gray-700 group-hover:text-gray-900 transition-colors duration-300">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* CTA Card */}
            <Card className="bg-gradient-to-r from-orange-500 to-purple-600 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 overflow-hidden">
              <CardContent className="p-8 relative">
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/10 rounded-full animate-pulse"></div>
                <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-white/5 rounded-full animate-float"></div>
                <div className="relative z-10">
                  <div className="flex items-center mb-4">
                    <Clock className="h-6 w-6 mr-3" />
                    <h4 className="text-xl font-bold">Ready to Start?</h4>
                  </div>
                  <p className="mb-6 opacity-90">
                    Let's discuss your project and see how we can help you achieve your goals.
                  </p>
                  <Button className="bg-white text-orange-600 hover:bg-gray-100 font-semibold px-6 py-3 rounded-xl hover:scale-105 transition-all duration-300">
                    Schedule a Call
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
