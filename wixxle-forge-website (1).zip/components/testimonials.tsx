"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Quote, ArrowLeft, ArrowRight, Play } from "lucide-react"

export function Testimonials() {
  const [activeTestimonial, setActiveTestimonial] = useState(0)
  const [visibleElements, setVisibleElements] = useState<number[]>([])
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const sectionRef = useRef<HTMLElement>(null)

  const testimonials = [
    {
      name: "Sarah Johnson",
      company: "TechStart Inc.",
      role: "CEO & Founder",
      photo: "/placeholder.svg?height=120&width=120",
      rating: 5,
      text: "Wixxle Forge transformed our vision into a stunning, functional website. Their attention to detail and technical expertise exceeded our expectations. The team's professionalism and dedication to quality is unmatched!",
      gradient: "from-blue-500 to-purple-600",
      projectType: "SaaS Dashboard",
    },
    {
      name: "Michael Chen",
      company: "LocalBiz Solutions",
      role: "Marketing Director",
      photo: "/placeholder.svg?height=120&width=120",
      rating: 5,
      text: "The team at Wixxle Forge delivered our e-commerce platform on time and within budget. The site performs flawlessly and has significantly boosted our online sales by 150% in just 3 months!",
      gradient: "from-green-500 to-teal-600",
      projectType: "E-commerce Platform",
    },
    {
      name: "Emily Rodriguez",
      company: "RestaurantPro",
      role: "Owner",
      photo: "/placeholder.svg?height=120&width=120",
      rating: 5,
      text: "Professional, responsive, and incredibly talented. Wixxle Forge created a beautiful website that perfectly represents our brand and engages our customers. Our online orders increased by 200%!",
      gradient: "from-orange-500 to-red-600",
      projectType: "Restaurant Website",
    },
    {
      name: "David Kim",
      company: "HealthCare Plus",
      role: "CTO",
      photo: "/placeholder.svg?height=120&width=120",
      rating: 5,
      text: "Outstanding work on our patient portal. The user experience is intuitive and the backend is robust. Wixxle Forge delivered exactly what we needed for our healthcare platform.",
      gradient: "from-purple-500 to-pink-600",
      projectType: "Healthcare Portal",
    },
  ]

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number.parseInt(entry.target.getAttribute("data-index") || "0")
            setVisibleElements((prev) => [...prev, index])
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = sectionRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((element) => observer.observe(element))

    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlaying, testimonials.length])

  const nextTestimonial = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    setIsAutoPlaying(false)
  }

  const prevTestimonial = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
    setIsAutoPlaying(false)
  }

  return (
    <section
      ref={sectionRef}
      className="py-20 bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 relative overflow-hidden"
    >
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 gradient-purple rounded-full opacity-10 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 gradient-orange rounded-full opacity-10 animate-float blur-3xl"
          style={{ animationDelay: "2s" }}
        ></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 gradient-blue rounded-full opacity-10 animate-morphing blur-2xl"></div>

        {/* Floating quotes */}
        <div className="absolute top-20 left-20 text-white/5 animate-float" style={{ animationDelay: "1s" }}>
          <Quote className="h-24 w-24" />
        </div>
        <div className="absolute bottom-20 right-20 text-white/5 animate-float" style={{ animationDelay: "3s" }}>
          <Quote className="h-32 w-32" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div
          className={`text-center mb-20 animate-on-scroll ${visibleElements.includes(0) ? "animate-fade-in-up" : "opacity-0"}`}
          data-index="0"
        >
          <div className="inline-flex items-center px-4 py-2 glass text-orange-400 rounded-full text-sm font-medium mb-4 animate-pulse-glow">
            <Star className="h-4 w-4 mr-2" />
            Client Success Stories
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            What Our{" "}
            <span className="bg-gradient-to-r from-orange-400 to-purple-400 bg-clip-text text-transparent">
              Clients Say
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Don't just take our word for it. Here's what our satisfied clients have to say about working with us.
          </p>
        </div>

        {/* Main Testimonial Display */}
        <div
          className={`animate-on-scroll ${visibleElements.includes(1) ? "animate-scale-in" : "opacity-0"}`}
          data-index="1"
          style={{ animationDelay: "0.3s" }}
        >
          <div className="relative max-w-4xl mx-auto">
            <Card className="glass border-white/10 shadow-2xl hover:shadow-3xl transition-all duration-500 overflow-hidden">
              <CardContent className="p-12 text-center relative">
                {/* Background gradient */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${testimonials[activeTestimonial].gradient} opacity-5`}
                ></div>

                {/* Quote icon */}
                <div className="absolute top-8 left-8 text-white/10">
                  <Quote className="h-16 w-16" />
                </div>

                {/* Rating */}
                <div className="flex justify-center mb-8">
                  {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-8 w-8 text-yellow-400 fill-current animate-pulse"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    />
                  ))}
                </div>

                {/* Testimonial text */}
                <blockquote className="text-2xl md:text-3xl text-white font-light leading-relaxed mb-12 italic relative z-10">
                  "{testimonials[activeTestimonial].text}"
                </blockquote>

                {/* Client info */}
                <div className="flex items-center justify-center space-x-6">
                  <div className="relative">
                    <img
                      src={testimonials[activeTestimonial].photo || "/placeholder.svg"}
                      alt={testimonials[activeTestimonial].name}
                      className="w-20 h-20 rounded-full object-cover border-4 border-white/20 hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-4 border-gray-900 animate-pulse"></div>
                  </div>
                  <div className="text-left">
                    <h4 className="text-xl font-bold text-white">{testimonials[activeTestimonial].name}</h4>
                    <p className="text-orange-400 font-medium">{testimonials[activeTestimonial].role}</p>
                    <p className="text-gray-400">{testimonials[activeTestimonial].company}</p>
                    <div className="inline-flex items-center mt-2 px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300">
                      <Play className="h-3 w-3 mr-1" />
                      {testimonials[activeTestimonial].projectType}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Navigation arrows */}
            <button
              onClick={prevTestimonial}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 glass rounded-full flex items-center justify-center text-white hover:text-orange-400 hover:scale-110 transition-all duration-300"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 glass rounded-full flex items-center justify-center text-white hover:text-orange-400 hover:scale-110 transition-all duration-300"
            >
              <ArrowRight className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Testimonial indicators */}
        <div
          className={`flex justify-center space-x-4 mt-12 animate-on-scroll ${visibleElements.includes(2) ? "animate-fade-in-up" : "opacity-0"}`}
          data-index="2"
          style={{ animationDelay: "0.6s" }}
        >
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setActiveTestimonial(index)
                setIsAutoPlaying(false)
              }}
              className={`w-4 h-4 rounded-full transition-all duration-300 ${
                index === activeTestimonial
                  ? "bg-gradient-to-r from-orange-400 to-purple-400 scale-125"
                  : "bg-white/30 hover:bg-white/50"
              }`}
            />
          ))}
        </div>

        {/* All testimonials grid */}
        <div
          className={`grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-20 animate-on-scroll ${visibleElements.includes(3) ? "animate-fade-in-up" : "opacity-0"}`}
          data-index="3"
          style={{ animationDelay: "0.9s" }}
        >
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className={`glass border-white/10 hover:border-white/20 transition-all duration-300 hover-lift cursor-pointer ${
                index === activeTestimonial ? "ring-2 ring-orange-400" : ""
              }`}
              onClick={() => {
                setActiveTestimonial(index)
                setIsAutoPlaying(false)
              }}
            >
              <CardContent className="p-6 text-center">
                <img
                  src={testimonial.photo || "/placeholder.svg"}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full mx-auto mb-4 object-cover border-2 border-white/20"
                />
                <h4 className="text-white font-semibold mb-1">{testimonial.name}</h4>
                <p className="text-gray-400 text-sm mb-2">{testimonial.company}</p>
                <div className="flex justify-center">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div
          className={`text-center mt-16 animate-on-scroll ${visibleElements.includes(4) ? "animate-scale-in" : "opacity-0"}`}
          data-index="4"
          style={{ animationDelay: "1.2s" }}
        >
          <div className="inline-flex items-center px-8 py-4 glass text-white rounded-2xl font-semibold text-lg hover:scale-105 transition-transform duration-300 cursor-pointer hover-glow">
            Ready to Join Our Success Stories?
            <ArrowRight className="ml-2 h-5 w-5" />
          </div>
        </div>
      </div>
    </section>
  )
}
