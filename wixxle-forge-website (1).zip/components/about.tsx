"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Target, Eye, Heart, Users, Award, Zap, ArrowRight } from "lucide-react"

export function About() {
  const [visibleElements, setVisibleElements] = useState<number[]>([])
  const [counters, setCounters] = useState({ projects: 0, clients: 0, experience: 0 })
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number.parseInt(entry.target.getAttribute("data-index") || "0")
            setVisibleElements((prev) => [...prev, index])

            // Animate counters
            if (entry.target.classList.contains("stats-section")) {
              animateCounters()
            }
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = sectionRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((element) => observer.observe(element))

    return () => observer.disconnect()
  }, [])

  const animateCounters = () => {
    const targets = { projects: 50, clients: 25, experience: 3 }
    const duration = 2000
    const steps = 60

    let step = 0
    const timer = setInterval(() => {
      step++
      const progress = step / steps
      const easeOut = 1 - Math.pow(1 - progress, 3)

      setCounters({
        projects: Math.floor(targets.projects * easeOut),
        clients: Math.floor(targets.clients * easeOut),
        experience: Math.floor(targets.experience * easeOut),
      })

      if (step >= steps) {
        clearInterval(timer)
        setCounters(targets)
      }
    }, duration / steps)
  }

  return (
    <section
      ref={sectionRef}
      id="about"
      className="py-20 bg-gradient-to-br from-white via-gray-50 to-purple-50 relative overflow-hidden"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 gradient-purple rounded-full opacity-5 animate-float blur-3xl"></div>
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 gradient-orange rounded-full opacity-5 animate-float blur-3xl"
          style={{ animationDelay: "2s" }}
        ></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 gradient-blue rounded-full opacity-5 animate-morphing blur-2xl"></div>

        {/* Floating shapes */}
        <div
          className="absolute top-20 right-20 w-4 h-4 bg-purple-300 rotate-45 animate-float opacity-40"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute bottom-32 left-32 w-6 h-6 bg-orange-300 rounded-full animate-float opacity-40"
          style={{ animationDelay: "3s" }}
        ></div>
        <div
          className="absolute top-1/3 right-1/3 w-3 h-3 bg-blue-300 animate-float opacity-40"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div
          className={`text-center mb-20 animate-on-scroll ${visibleElements.includes(0) ? "animate-fade-in-up" : "opacity-0"}`}
          data-index="0"
        >
          <div className="inline-flex items-center px-4 py-2 bg-purple-100 text-purple-800 rounded-full text-sm font-medium mb-4 animate-pulse-glow">
            <Users className="h-4 w-4 mr-2" />
            About Our Team
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            About{" "}
            <span className="bg-gradient-to-r from-purple-600 to-orange-600 bg-clip-text text-transparent">
              Wixxle Forge
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            We're a passionate team of developers and designers dedicated to creating exceptional digital experiences
            that drive business growth and innovation.
          </p>
        </div>

        {/* Mission, Vision, Values Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {[
            {
              icon: Target,
              title: "Our Mission",
              description: "To empower businesses with cutting-edge web solutions that drive growth and success.",
              gradient: "from-orange-500 to-red-600",
              bgGradient: "from-orange-50 to-red-50",
            },
            {
              icon: Eye,
              title: "Our Vision",
              description: "To be the leading web development partner for innovative businesses worldwide.",
              gradient: "from-purple-500 to-pink-600",
              bgGradient: "from-purple-50 to-pink-50",
            },
            {
              icon: Heart,
              title: "Our Values",
              description: "Quality, innovation, and client satisfaction are at the heart of everything we do.",
              gradient: "from-blue-500 to-indigo-600",
              bgGradient: "from-blue-50 to-indigo-50",
            },
          ].map((item, index) => (
            <Card
              key={index}
              data-index={index + 1}
              className={`animate-on-scroll group relative overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover-lift ${
                visibleElements.includes(index + 1) ? "animate-scale-in" : "opacity-0"
              }`}
              style={{
                animationDelay: `${index * 0.2}s`,
                background: `linear-gradient(135deg, ${item.bgGradient.replace("from-", "").replace(" to-", ", ")})`,
              }}
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
              ></div>
              <div className="absolute top-4 right-4 w-20 h-20 bg-white/20 rounded-full blur-xl group-hover:scale-150 transition-transform duration-500"></div>

              <CardContent className="p-8 text-center relative z-10">
                <div
                  className={`w-16 h-16 bg-gradient-to-r ${item.gradient} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}
                >
                  <item.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-900">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Team and Stats Section */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Team Section */}
          <div
            className={`animate-on-scroll ${visibleElements.includes(4) ? "animate-slide-left" : "opacity-0"}`}
            data-index="4"
            style={{ animationDelay: "0.3s" }}
          >
            <h3 className="text-3xl font-bold text-gray-900 mb-8 flex items-center">
              <Award className="h-8 w-8 text-orange-500 mr-3" />
              Meet Our Team
            </h3>

            <div className="space-y-8">
              {[
                {
                  name: "John Doe",
                  role: "Founder & Lead Developer",
                  bio: "Full-stack developer with 8+ years of experience in modern web technologies.",
                  initials: "JD",
                  gradient: "from-orange-400 to-orange-600",
                  skills: ["React", "Node.js", "TypeScript", "AWS"],
                },
                {
                  name: "Jane Smith",
                  role: "Co-Founder & UX Designer",
                  bio: "Creative designer specializing in user experience and interface design.",
                  initials: "JS",
                  gradient: "from-purple-400 to-purple-600",
                  skills: ["Figma", "Adobe XD", "User Research", "Prototyping"],
                },
              ].map((member, index) => (
                <div
                  key={index}
                  className="group flex items-center space-x-6 p-6 rounded-2xl hover:bg-white/50 transition-all duration-300 hover-lift"
                >
                  <div
                    className={`relative w-20 h-20 bg-gradient-to-br ${member.gradient} rounded-2xl flex items-center justify-center text-white font-bold text-xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}
                  >
                    {member.initials}
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-white animate-pulse"></div>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-xl font-bold text-gray-900 group-hover:text-orange-600 transition-colors duration-300">
                      {member.name}
                    </h4>
                    <p className="text-purple-600 font-medium mb-2">{member.role}</p>
                    <p className="text-gray-600 text-sm mb-3">{member.bio}</p>
                    <div className="flex flex-wrap gap-2">
                      {member.skills.map((skill, skillIndex) => (
                        <span
                          key={skillIndex}
                          className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md hover:bg-orange-100 hover:text-orange-700 transition-colors duration-300"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Stats and Why Choose Us */}
          <div
            className={`animate-on-scroll ${visibleElements.includes(5) ? "animate-slide-right" : "opacity-0"}`}
            data-index="5"
            style={{ animationDelay: "0.5s" }}
          >
            {/* Animated Stats */}
            <div className="stats-section animate-on-scroll mb-12" data-index="6">
              <h3 className="text-2xl font-bold text-gray-900 mb-8 flex items-center">
                <Zap className="h-6 w-6 text-purple-500 mr-3" />
                Our Impact
              </h3>
              <div className="grid grid-cols-3 gap-6">
                {[
                  { number: counters.projects, suffix: "+", label: "Projects", color: "text-orange-500" },
                  { number: counters.clients, suffix: "+", label: "Clients", color: "text-purple-500" },
                  { number: counters.experience, suffix: "+", label: "Years", color: "text-blue-500" },
                ].map((stat, index) => (
                  <div key={index} className="text-center group">
                    <div
                      className={`text-4xl font-bold ${stat.color} mb-2 group-hover:scale-110 transition-transform duration-300`}
                    >
                      {stat.number}
                      {stat.suffix}
                    </div>
                    <div className="text-gray-600 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Why Choose Us */}
            <Card className="bg-gradient-to-br from-gray-50 to-purple-50 border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
              <CardContent className="p-8 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-200/30 to-orange-200/30 rounded-full -translate-y-16 translate-x-16 animate-float"></div>
                <h3 className="text-2xl font-bold mb-6 text-gray-900 flex items-center">
                  <Award className="h-6 w-6 text-orange-500 mr-3" />
                  Why Choose Us?
                </h3>
                <ul className="space-y-4">
                  {[
                    "Expert team with proven track record",
                    "Custom solutions tailored to your needs",
                    "Latest technologies and best practices",
                    "Ongoing support and maintenance",
                    "Competitive pricing and timely delivery",
                  ].map((item, index) => (
                    <li key={index} className="flex items-center group">
                      <div className="w-3 h-3 bg-gradient-to-r from-orange-500 to-purple-600 rounded-full mr-4 group-hover:scale-150 transition-transform duration-300"></div>
                      <span className="text-gray-700 group-hover:text-gray-900 transition-colors duration-300">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="mt-8">
                  <button className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-orange-500 to-purple-600 text-white rounded-xl font-semibold hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl">
                    Learn More About Us
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
